class analysis_method_example():

	def __init__(self):
			self.var1 = 1
	
	def process(self, data):
		return 0
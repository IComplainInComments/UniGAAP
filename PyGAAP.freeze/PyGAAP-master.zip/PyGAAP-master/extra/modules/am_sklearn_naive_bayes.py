from sklearn.feature_extraction.text import CountVectorizer

class sklearn_naive_bayes():
	max_features = 1000
	def __init__(self):
		self.max_features = 1000
		...

	def train(self, text_features):
		...
	
	def predict(self, text_features):
		...

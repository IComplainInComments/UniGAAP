# Recursively remove all __pycache__ directories and their contents from the project directory
find . -path '*/__pycache__*' -delete
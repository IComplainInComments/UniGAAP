# PyGAAP Constants
version = "1.0.0 alpha 1"
versiondate = "2022.03.10"